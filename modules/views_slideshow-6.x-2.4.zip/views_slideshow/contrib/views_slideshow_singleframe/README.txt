
Views Slideshow: SingleFrame
============================

The original default slideshow mode for Views Slideshow.


Description
===========

The Views Slideshow: Single Frame adds a Views display for showing rows as items
in a jQuery slideshow. Rows could be single images, full nodes, or whatever else
that Views can display.

Controls can be added to control the slideshow in the form of numbers or
thumbnails.
