<div<?php print drupal_attributes($attributes); ?>>
  <?php print $rendered_field_items; ?>
</div>
